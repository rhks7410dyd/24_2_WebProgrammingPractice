import React from 'react';
import Title  from './mainTypography';
import Subtitle  from './mainTypography';
import Para  from './mainTypography';

const MainContent = () => (
  <div className="flex-grow bg-white p-16">
    <Title>Assignment</Title>
    <Para>
      You need to zip the following files and submit zip file on iCampus.
    </Para>
  </div>
);

export default MainContent;