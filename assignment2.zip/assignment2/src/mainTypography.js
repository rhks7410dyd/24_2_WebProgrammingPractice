import React from 'react';

const Title = ({ innerText }) => (
  <h1 className="text-3xl font-bold mb-4">
    {innerText}
  </h1>
);

const Subtitle = ({ innerText }) => (
  <h2 className="text-2xl font-semibold mb-2">
    {innerText}
  </h2>
);

const Para = ({ innerText }) => (
  <p className="text-lg mb-4">
    {innerText}
  </p>
);

export { Title, Subtitle, Para };